package com.example.quizapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.quizapp.R
import com.example.quizapp.ui.components.AppBar

@Composable
fun CategorySelectionScreen(onCategorySelected: (String) -> Unit) {
    Scaffold(
        topBar = { AppBar(title = "Выберите категорию") } // Kategoriya tanlash yozuvi AppBarda
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CategoryButton("Флаги", R.drawable.baseline_add_home_24, onCategorySelected)
            CategoryButton("Деньги", R.drawable.baseline_attach_money_24, onCategorySelected)
            CategoryButton("Столицы", R.drawable.baseline_add_location_24, onCategorySelected)
        }
    }
}

@Composable
fun CategoryButton(text: String, iconRes: Int, onClick: (String) -> Unit) {
    Button(
        onClick = { onClick(text) },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .height(60.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = iconRes),
                contentDescription = text,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = text, fontSize = 18.sp)
        }
    }
}

@Preview
@Composable
fun PreviewCategorySelectionScreen() {
    CategorySelectionScreen(onCategorySelected = {})
}

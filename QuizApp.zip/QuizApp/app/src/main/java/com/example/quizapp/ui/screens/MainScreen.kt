package com.example.quizapp.ui.screens

import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.quizapp.ui.components.TopAppBarContent
import com.example.quizapp.ui.screens.quiz.CapitalsQuizScreen
import com.example.quizapp.ui.screens.quiz.FlagsQuizScreen
import com.example.quizapp.ui.screens.quiz.MoneyQuizScreen

@Composable
fun MainScreen() {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedRegion by  remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { TopAppBarContent() } // TopAppBar qo'shildi
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedCategory) {
                "Флаги" -> FlagsQuizScreen(selectedRegion!!) { selectedCategory = null; selectedRegion = null }
                "Деньги" -> MoneyQuizScreen(selectedRegion!!) { selectedCategory = null; selectedRegion = null }
                "Столицы" -> CapitalsQuizScreen(selectedRegion!!) { selectedCategory = null; selectedRegion = null }
                else -> CategorySelectionScreen { selectedCategory = it }
            }
        }
    }
}

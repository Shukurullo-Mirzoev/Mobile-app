@file:OptIn(ExperimentalMaterial3Api::class)

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun TopAppBarContent(darkMode: Boolean, onThemeChange: () -> Unit) {
    TopA
    ppBar(
        title = { Text(text = "Настройки") },
        actions = {
            IconButton(onClick = onThemeChange) {
                Icon(
                    imageVector = if (darkMode) Icons.Filled.Brightness4 else Icons.Filled.Brightness7,
                    contentDescription = "Theme"
                )
            }
        }
    )
}
